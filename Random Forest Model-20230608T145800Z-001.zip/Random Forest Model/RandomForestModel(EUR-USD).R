# Random Forest Model

# Load the required libraries
library(randomForest)
library(tidyverse)

# Load the data
data <- read_csv("~/Downloads/forexEURUSD.csv")

# Split the data into training and test sets
set.seed(123) # for reproducibility
train_index <- sample(nrow(data), 0.7*nrow(data))
train_data <- data[train_index, ]
test_data <- data[-train_index, ]

# Build the random forest model
model <- randomForest(close ~ open + high + low, data = train_data, ntree = 500)

# Make predictions on the test set
predictions <- predict(model, newdata = test_data)

# Calculate RMSE and R-squared
rmse <- sqrt(mean((test_data$close - predictions)^2))
rsq <- cor(test_data$close, predictions)^2

# Print the results for random forest model
cat("RMSE:", rmse, "\n")
cat("R-squared:", rsq, "\n")

# Calculate the mean absolute error (MAE)
mae <- mean(abs(predictions - test_data$close))

# Plot the actual vs. predicted values using ggplot2
plot_data <- tibble(actual = test_data$close, predicted = predictions)
ggplot(plot_data, aes(x = 1:length(actual))) +
  geom_line(aes(y = actual, color = "Actual")) +
  geom_line(aes(y = predicted, color = "Predicted")) +
  scale_color_manual(name = "Legend", values = c("red", "lightgreen")) +
  xlab("Observation") +
  ylab("Close Price") +
  ggtitle(paste("Random Forest Model for EUR/USD (MAE =", round(mae, 4), ")")) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1), plot.title = element_text(hjust = 0.5))
