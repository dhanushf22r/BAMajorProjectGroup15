# ARIMA (Autoregressive Integrated Moving Average) Model

# Load necessary packages
library(tidyverse)
library(lubridate)
library(forecast)
library(tseries)

# Read in the data
data <- read.csv("file:///Users/ravi/Downloads/forexEURAED.csv")

# Convert the date column to a date format
data$date <- dmy(data$date)

# Subset the data to only include the relevant columns
data <- data %>% select(date, close)

# Plot the time series data
ggplot(data, aes(x = date, y = close)) +
  geom_line() +
  labs(title = "EUR/AED Exchange Rates plot over the Years", x = "Years", y = "Exchange Rate") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1), plot.title = element_text(hjust = 0.5))

# Create a time series object
ts_data <- ts(data$close, frequency = 365)

# Decompose the time series to check for trend and seasonality
decomposed_ts <- decompose(ts_data)
plot(decomposed_ts)

# Check for stationarity using ADF test
adf_test <- adf.test(ts_data)
adf_test$p.value

# If not stationary, difference the time series to make it stationary
diff_ts <- diff(ts_data)
diff_adf_test <- adf.test(diff_ts)
diff_adf_test$p.value

# Find the optimal ARIMA model
auto_arima_model <- auto.arima(ts_data)
auto_arima_model

# Check the residuals of the model for normality and stationarity
checkresiduals(auto_arima_model)

# Forecast future values of EUR/AED using the ARIMA model
forecast_data <- forecast(auto_arima_model, h = 365)

# Plot the forecasted values
plot(forecast_data, xlab = "Time (For first 15 Days)", ylab = "Exchange Rate",
     main = "Forecasted EUR/AED Exchange Rates")

#---------------------------------------------------------------------#

# LSTM

# Load necessary packages
library(keras)
library(dplyr)
library(keras)
library(tidyverse)

# Load required libraries
library(keras)
library(tidyverse)

# Load the data
df <- read.csv('file:///Users/ravi/Downloads/forexEURAED.csv')
df$date <- as.Date(df$date, format = '%m/%d/%Y')

# Preprocess the data
data <- df %>%
  filter(slug == 'EUR/AED') %>%
  select(close) %>%
  as.matrix()

train_size <- floor(nrow(data) * 0.8)
train_data <- data[1:train_size, ]
test_data <- data[(train_size + 1):nrow(data), ]

# Define the model architecture
model <- keras_model_sequential() %>%
  layer_lstm(units = 50, input_shape = c(1, 1)) %>%
  layer_dense(units = 1)

# Compile the model
model %>% compile(
  optimizer = 'adam',
  loss = 'mse'
)

# Train the model
train_data_matrix <- as.matrix(train_data)
model %>% fit(
  x = train_data_matrix[-nrow(train_data_matrix), , drop = FALSE],
  y = train_data_matrix[-1, , drop = FALSE],
  epochs = 100,
  batch_size = 1
)

# Evaluate the model
test_loss <- model %>% evaluate(
  x = train_data_matrix[-dim(train_data_matrix)[1], , drop = FALSE],
  y = train_data_matrix[-1, , drop = FALSE],
  verbose = 0
)

# Make predictions
predictions <- model %>% predict(
  x = train_data_matrix[-dim(train_data_matrix)[1], , drop = FALSE],
  verbose = 0
)

# Plot the results
plot(train_data_matrix[-1, ], type = 'l', col = 'red', ylab = 'EUR/AED', xlab = 'Time', 
     main = 'Actual vs Predicted EUR/AED LSTM')
lines(predictions, col = 'black')
legend('topright', legend = c('Actual', 'Predicted'), col = c('red', 'black'), lty = 1, cex = 0.8)
